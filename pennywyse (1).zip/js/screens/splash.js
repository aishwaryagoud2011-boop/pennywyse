(function (global) {
  const PW = (global.PW = global.PW || {});

  function renderSplashScreen(container, ctx) {
    const {
      apiRequest,
      setStoredToken,
      CURRENCY_META,
      pennywyseLogoSvg,
      iconSvg,
      escapeHtml,
    } = PW;

    const knownWorkspaces = PW.getKnownLocalWorkspaces ? PW.getKnownLocalWorkspaces() : [];
    const primaryWorkspace = knownWorkspaces.length > 0 ? knownWorkspaces[0] : null;

    const local = {
      name: '',
      currency: 'INR',
      monthlyBudget: '',
      loading: false,
      error: null,
    };

    const symbol = () => CURRENCY_META[local.currency]?.symbol || '₹';

    function render() {
      container.innerHTML = `
        <div class="splash-screen" style="justify-content:space-between;padding:24px 20px;">
          <div style="text-align:center;margin-top:12px;">
            <div style="display:flex;justify-content:center;">
              ${pennywyseLogoSvg('lg')}
            </div>
            <h1 class="splash-title" style="margin-top:12px;">pennywyse</h1>
            <p class="splash-subtitle">take control of every expense</p>
          </div>

          <div style="width:100%;max-width:360px;margin:20px auto;background:#ffffff;border:1px solid #e5e5e5;border-radius:20px;padding:18px;box-shadow:0 12px 30px rgba(0,0,0,0.06);">
            ${
              primaryWorkspace
                ? `
                  <div class="stack-sm" style="margin-bottom:14px;">
                    <p style="font-size:12px;font-weight:600;color:#525252;">Saved local profile found</p>
                    <button type="button" id="splashResumeBtn" class="btn-primary">
                      <span>Continue as ${escapeHtml(primaryWorkspace.user.name)}</span>
                    </button>
                    <div class="or-divider" style="margin:6px 0;">OR START NEW PROFILE</div>
                  </div>
                `
                : `
                  <p class="font-serif" style="font-size:15px;font-weight:700;color:#171717;margin-bottom:4px;">
                    Quick Setup (Saved on this device)
                  </p>
                  <p style="font-size:12px;color:#737373;margin-bottom:14px;">
                    No account sign-up needed. Everything stays saved in your browser.
                  </p>
                `
            }

            <form id="quickStartForm" class="stack-md">
              <div>
                <label class="field-label" for="qsName">Your Name (Optional)</label>
                <input
                  id="qsName"
                  type="text"
                  value="${escapeHtml(local.name)}"
                  placeholder="e.g., Aishwarya"
                  class="input"
                />
              </div>

              <div>
                <label class="field-label">Preferred Currency</label>
                <div class="currency-grid">
                  ${Object.keys(CURRENCY_META)
                    .map(
                      (code) => `
                        <button type="button" data-qs-currency="${code}" class="currency-choice ${local.currency === code ? 'active' : ''}">
                          ${escapeHtml(CURRENCY_META[code].label)}
                        </button>
                      `
                    )
                    .join('')}
                </div>
              </div>

              <div>
                <label class="field-label" for="qsBudget">Monthly Budget (${escapeHtml(symbol())}, Optional)</label>
                <input
                  id="qsBudget"
                  type="number"
                  min="0"
                  step="any"
                  value="${escapeHtml(local.monthlyBudget)}"
                  placeholder="e.g., 40000"
                  class="input tabular-nums"
                />
              </div>

              ${local.error ? `<p class="error-text">${escapeHtml(local.error)}</p>` : ''}

              <button type="submit" id="splashExploreBtn" ${local.loading ? 'disabled' : ''} class="${primaryWorkspace ? 'btn-secondary' : 'btn-primary'}">
                ${local.loading ? '<span class="spinner"></span>' : iconSvg('sparkles', 16)}
                <span>${local.loading ? 'Opening Dashboard...' : 'Start Using App'}</span>
              </button>
            </form>
          </div>

          <div style="text-align:center;margin-bottom:4px;">
            <button type="button" id="splashOptionalSignInBtn" style="font-size:12px;color:#737373;text-decoration:underline;">
              Sign in or restore with email / Google
            </button>
          </div>
        </div>
      `;

      container.querySelector('#qsName')?.addEventListener('input', (e) => {
        local.name = e.target.value;
      });
      container.querySelector('#qsBudget')?.addEventListener('input', (e) => {
        local.monthlyBudget = e.target.value;
      });
      container.querySelectorAll('[data-qs-currency]').forEach((btn) => {
        btn.addEventListener('click', () => {
          local.currency = btn.dataset.qsCurrency;
          render();
        });
      });

      container.querySelector('#splashResumeBtn')?.addEventListener('click', async () => {
        if (ctx.state.user) {
          ctx.navigate('home');
          return;
        }
        const saved = PW.getSavedSessionSnapshot ? PW.getSavedSessionSnapshot() : null;
        if (saved && saved.user) {
          ctx.onAuthenticated(saved, { forceHome: true });
          return;
        }
        if (primaryWorkspace) {
          const res = await apiRequest('/api/auth/restore', {
            method: 'POST',
            body: primaryWorkspace,
          });
          setStoredToken(res.token);
          ctx.onAuthenticated(res, { forceHome: true });
        }
      });

      container.querySelector('#quickStartForm')?.addEventListener('submit', async (e) => {
        e.preventDefault();
        if (ctx.state.user) {
          ctx.navigate('home');
          return;
        }
        const saved = PW.getSavedSessionSnapshot ? PW.getSavedSessionSnapshot() : null;
        if (saved && saved.user && !local.name.trim() && !local.monthlyBudget) {
          ctx.onAuthenticated(saved, { forceHome: true });
          return;
        }
        local.loading = true;
        local.error = null;
        render();
        try {
          const res = await apiRequest('/api/auth/quick-start', {
            method: 'POST',
            body: {
              name: local.name.trim(),
              currency: local.currency,
              monthlyBudget: Number(local.monthlyBudget) || 0,
            },
          });
          setStoredToken(res.token);
          ctx.onAuthenticated(
            { user: res.user, transactions: res.transactions, savingGoals: res.savingGoals },
            { forceHome: true }
          );
        } catch (err) {
          local.loading = false;
          local.error = err instanceof Error ? err.message : 'Could not start app';
          render();
        }
      });

      container.querySelector('#splashOptionalSignInBtn')?.addEventListener('click', () => {
        ctx.navigate('welcome');
      });
    }

    render();
  }

  PW.renderSplashScreen = renderSplashScreen;
})(window);
