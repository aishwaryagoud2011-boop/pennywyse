import 'dotenv/config';
import fs from 'node:fs';
import http from 'node:http';
import path from 'node:path';
import express from 'express';
import { GoogleGenAI } from '@google/genai';

function getGeminiClient() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return null;
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

const app = express();
app.use(express.json({ limit: '2mb' }));

// Health check for frontend backend detection
app.get('/api/health', (_req, res) => {
  res.json({ ok: true });
});

// Gemini AI Financial Coach Chat (keeps GEMINI_API_KEY strictly on the server)
app.post('/api/ai/chat', async (req, res) => {
  const ai = getGeminiClient();
  if (!ai) {
    res.status(503).json({
      error: 'Gemini API key is not configured on the server yet. Please configure GEMINI_API_KEY in Settings > Secrets.',
    });
    return;
  }

  const message = String(req.body?.message || '').trim();
  const history = Array.isArray(req.body?.history) ? req.body.history : [];
  const financialSummary = req.body?.financialSummary || {};

  if (!message) {
    res.status(400).json({ error: 'Please enter a message.' });
    return;
  }

  try {
    const systemInstruction = [
      'You are Pennywyse AI, a practical, warm, concise personal finance coach inside the Pennywyse mobile app.',
      'Your advice must be grounded strictly in the user-entered Pennywyse data provided in the snapshot (their balance, monthly budget, category limits, transactions, monthly savings target, 4 saving goals, and calculated EMI & tax).',
      'Refer to exact numbers, categories, category limits (>=80% warnings or exceeded categories), and goal gaps from their snapshot when helpful.',
      'Help the user explore "what-if" savings plans, cut discretionary spending, prioritize saving goals, or manage monthly EMI & tax obligations.',
      'Never invent fake transactions, fake balances, or claim live external bank/UPI connections.',
      'Keep answers crisp, structured for mobile screens (short paragraphs or concise bullet points), and always use the user currency.',
      `Current User Financial Snapshot: ${JSON.stringify(financialSummary)}`,
    ].join('\n');

    const conversationContext = history
      .slice(-10)
      .map((m) => `${m.role === 'user' ? 'User' : 'Pennywyse AI'}: ${m.content}`)
      .join('\n');

    const prompt = conversationContext
      ? `${conversationContext}\nUser: ${message}\nPennywyse AI:`
      : `User: ${message}`;

    let response = null;
    for (let attempt = 0; attempt < 3; attempt++) {
      try {
        response = await ai.models.generateContent({
          model: 'gemini-4-hydrogen',
          contents: prompt,
          config: {
            systemInstruction,
          },
        });
        break;
      } catch (err) {
        const msg = err instanceof Error ? err.message : String(err || '');
        const isTransient = /503|429|UNAVAILABLE|RESOURCE_EXHAUSTED|high demand/i.test(msg);
        if (!isTransient || attempt === 2) throw err;
        await new Promise((resolve) => setTimeout(resolve, 600 * (attempt + 1)));
      }
    }

    const reply =
      response?.text?.trim() ||
      'I reviewed your Pennywyse numbers—try trimming your top discretionary category by 10% this month to reach your savings target faster.';
    res.json({ reply });
  } catch (err) {
    const errMsg = err instanceof Error ? err.message : 'AI request failed';
    res.status(500).json({ error: `Pennywyse AI encountered an issue: ${errMsg}` });
  }
});

// Serve plain HTML, CSS, and JavaScript assets
const rootDir = process.cwd();
const publicAssetsDir = path.resolve(rootDir, 'public', 'assets');
const distDir = path.resolve(rootDir, 'dist');
const useDist =
  process.env.NODE_ENV === 'production' && fs.existsSync(path.join(distDir, 'index.html'));
const entryDir = useDist ? distDir : rootDir;

// Kill-switch for any legacy vite-plugin-pwa /dev-sw.js registration in the user's browser
app.get('/dev-sw.js', (_req, res) => {
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate');
  res.type('application/javascript').send(`
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.map((k) => caches.delete(k)));
    await self.registration.unregister();
    const clients = await self.clients.matchAll({ type: 'window' });
    for (const client of clients) {
      client.navigate(client.url);
    }
  })());
});
`);
});

app.get('/registerSW.js', (_req, res) => {
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate');
  res.type('application/javascript').send('// Handled by ./js/pwa.js\n');
});

app.get('/manifest.json', (_req, res) => {
  res.setHeader('Cache-Control', 'no-cache');
  res.type('application/manifest+json');
  res.sendFile(path.join(entryDir, 'manifest.json'));
});

app.get('/manifest.webmanifest', (_req, res) => {
  res.setHeader('Cache-Control', 'no-cache');
  res.type('application/manifest+json');
  res.sendFile(path.join(entryDir, 'manifest.webmanifest'));
});

app.get('/sw.js', (_req, res) => {
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate');
  res.type('application/javascript');
  res.sendFile(path.join(entryDir, 'sw.js'));
});

if (useDist) {
  app.use(
    express.static(distDir, {
      setHeaders: (res, filePath) => {
        if (filePath.endsWith('sw.js') || filePath.endsWith('.html')) {
          res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate');
        } else {
          res.setHeader('Cache-Control', 'no-cache');
        }
      },
    })
  );
} else {
  const staticOpts = {
    setHeaders: (res) => {
      res.setHeader('Cache-Control', 'no-cache');
    },
  };
  app.use('/css', express.static(path.join(rootDir, 'css'), staticOpts));
  app.use('/js', express.static(path.join(rootDir, 'js'), staticOpts));
  if (fs.existsSync(publicAssetsDir)) {
    app.use('/assets', express.static(publicAssetsDir, staticOpts));
  }

  const rootAssetFiles = [
    '/icon.svg',
    '/apple-touch-icon.png',
    '/pwa-192x192.png',
    '/pwa-512x512.png',
    '/pwa-maskable-512x512.png',
    '/favicon.ico',
  ];
  for (const rel of rootAssetFiles) {
    app.get(rel, (_req, res) => {
      const target = path.join(rootDir, rel.slice(1));
      if (!fs.existsSync(target)) {
        res.status(404).end();
        return;
      }
      res.setHeader('Cache-Control', 'no-cache');
      res.sendFile(target);
    });
  }

  app.get(['/', '/index.html'], (_req, res) => {
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate');
    res.sendFile(path.join(rootDir, 'index.html'));
  });
}

app.get('*', (req, res) => {
  const reqPath = req.path || '';
  if (
    reqPath.startsWith('/api/') ||
    reqPath.startsWith('/@') ||
    reqPath.startsWith('/src/') ||
    /\.(js|mjs|ts|tsx|jsx|css|map|png|jpg|jpeg|gif|svg|ico|webp|woff2?|json|webmanifest)$/i.test(reqPath)
  ) {
    res.status(404).end();
    return;
  }
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate');
  res.sendFile(path.join(entryDir, 'index.html'));
});

const PORT = Number(process.env.PORT) || 3000;
const httpServer = http.createServer(app);
httpServer.listen(PORT, '0.0.0.0', () => {
  console.log(
    `Pennywyse server running on http://0.0.0.0:${PORT} (serving ${useDist ? 'dist/' : 'root index.html'})`
  );
});
